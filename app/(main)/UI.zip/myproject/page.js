import MyProjectClientPage from './MyProjectClientPage';

export default function MyProjectPage() {
  return (
    <MyProjectClientPage />
  );
}
