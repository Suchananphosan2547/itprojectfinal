import ComplacenceClientPage from "./ComplacenceClientPage";

export default function ComplacencePage() {
    return (
        <ComplacenceClientPage />
    );
}