'use client'

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { FaPlus, FaPenSquare, FaTrash, FaCheckCircle, FaXmark, FaCheck, FaExclamationCircle } from 'react-icons/fa';
import Cookies from 'js-cookie';

const API_URL = process.env.NEXT_PUBLIC_API_URL;

// =============================================================================
// ==== MOCK DATA ==============================================================
// =============================================================================
const MOCK_DATA = {
    STUDENT_ID: '6521651170',
    STUDENT_PROJECTS: [
        { project_id: 'proj-001', project_title: 'โครงการ TRUN IT ON ครั้งที่ 17', assessment_id: 'ass-001' },
        { project_id: 'proj-002', project_title: 'โครงการอบรมเชิงปฏิบัติการ AI', assessment_id: 'ass-002' },
    ],
    SURVEY_DETAILS: {
        'ass-001': {
            assessment_id: 'ass-001',
            project_name: 'TRUN IT ON ครั้งที่ 17',
            questions: [
                { questions_id: 'q-001', questions_name: 'ความพึงพอใจต่อเนื้อหาการอบรม', question_type: 'complacence' },
                { questions_id: 'q-002', questions_name: 'ความเหมาะสมของระยะเวลาโครงการ', question_type: 'complacence' },
                { questions_id: 'q-003', questions_name: 'ข้อเสนอแนะเพิ่มเติมสำหรับโครงการ', question_type: 'suggestions' },
            ],
        },
        'ass-002': {
            assessment_id: 'ass-002',
            project_name: 'อบรมเชิงปฏิบัติการ AI',
            questions: [
                { questions_id: 'q-004', questions_name: 'คุณภาพของวิทยากร', question_type: 'complacence' },
                { questions_id: 'q-005', questions_name: 'ความพึงพอใจต่อสถานที่จัดอบรม', question_type: 'complacence' },
            ],
        },
    },
    ADMIN_ASSESSMENTS: [
        { assessment_id: 'ass-001', project_id: 'proj-001', project_name: 'โครงการ TRUN IT ON ครั้งที่ 17', evaluation_status: 'active' },
        { assessment_id: 'ass-002', project_id: 'proj-002', project_name: 'โครงการอบรมเชิงปฏิบัติการ AI', evaluation_status: 'unused' },
        { assessment_id: 'ass-003', project_id: 'proj-003', project_name: 'โครงการฝึกงานในองค์กร', evaluation_status: 'active' },
    ],
    ADMIN_PROJECTS: [
        { project_id: 'proj-001', project_title: 'โครงการ TRUN IT ON ครั้งที่ 17' },
        { project_id: 'proj-002', project_title: 'โครงการอบรมเชิงปฏิบัติการ AI' },
        { project_id: 'proj-003', project_title: 'โครงการฝึกงานในองค์กร' },
        { project_id: 'proj-004', project_title: 'โครงการสร้างสรรค์นวัตกรรม' },
    ],
    ADMIN_QUESTIONS: {
        'ass-001': [
            { questions_id: 'q-001', questions_name: 'ความพึงพอใจต่อเนื้อหาการอบรม', question_type: 'complacence', questions_status: 'active' },
            { questions_id: 'q-002', questions_name: 'ความเหมาะสมของระยะเวลาโครงการ', question_type: 'complacence', questions_status: 'active' },
            { questions_id: 'q-003', questions_name: 'ข้อเสนอแนะเพิ่มเติมสำหรับโครงการ', question_type: 'suggestions', questions_status: 'active' },
        ],
        'ass-002': [
            { questions_id: 'q-004', questions_name: 'คุณภาพของวิทยากร', question_type: 'complacence', questions_status: 'active' },
            { questions_id: 'q-005', questions_name: 'ความพึงพอใจต่อสถานที่จัดอบรม', question_type: 'complacence', questions_status: 'active' },
        ],
        'ass-003': [
            { questions_id: 'q-006', questions_name: 'ความพึงพอใจต่อการดูแลของที่ปรึกษา', question_type: 'complacence', questions_status: 'active' },
            { questions_id: 'q-007', questions_name: 'สภาพแวดล้อมในการฝึกงาน', question_type: 'complacence', questions_status: 'active' },
            { questions_id: 'q-008', questions_name: 'ข้อเสนอแนะสำหรับการฝึกงาน', question_type: 'suggestions', questions_status: 'active' },
        ],
    },
};


// =============================================================================
// ==== COMPONENT: STUDENT ROLE ================================================
// =============================================================================
const StudentSurveyForm = ({ survey, onBack, onSubmit }) => {
    const [answers, setAnswers] = useState({});

    useEffect(() => {
        if (survey) {
            const initialAnswers = {};
            survey.questions.forEach(q => {
                initialAnswers[q.questions_id] = q.question_type === 'complacence' ? '5' : '';
            });
            setAnswers(initialAnswers);
        }
    }, [survey]);

    const handleChange = (questionId, value) => {
        setAnswers(prev => ({ ...prev, [questionId]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await onSubmit(survey.assessment_id, answers);
        } catch (err) {
            Swal.fire('Error', err.response?.data?.message || 'Failed to submit survey.', 'error');
        }
    };

    if (!survey) return <div className="p-8 text-center text-slate-500">ไม่พบแบบประเมิน</div>;

    const ratingOptions = [
        { value: '5', label: 'มากที่สุด' },
        { value: '4', label: 'มาก' },
        { value: '3', label: 'ปานกลาง' },
        { value: '2', label: 'น้อย' },
        { value: '1', label: 'น้อยที่สุด' },
    ];

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">{`แบบประเมินโครงการ ${survey.project_name}`}</h2>
            <form onSubmit={handleSubmit}>
                {survey.questions.map((q, index) => (
                    <div key={q.questions_id} className="bg-white rounded-xl shadow-md p-6 mb-6">
                        <h4 className="text-xl font-semibold text-slate-700 mb-4">
                            {`${index + 1}. ${q.questions_name}`}
                        </h4>
                        {q.question_type === 'complacence' ? (
                            <div className="space-y-2">
                                {ratingOptions.map(option => (
                                    <label key={option.value} className="flex items-center space-x-2 cursor-pointer">
                                        <input
                                            type="radio"
                                            name={`question-${q.questions_id}`}
                                            value={option.value}
                                            checked={answers[q.questions_id] === option.value}
                                            onChange={() => handleChange(q.questions_id, option.value)}
                                            className="form-radio h-5 w-5 text-blue-600"
                                            required
                                        />
                                        <span className="text-slate-600">{option.label}</span>
                                    </label>
                                ))}
                            </div>
                        ) : (
                            <textarea
                                rows="4"
                                value={answers[q.questions_id] || ''}
                                onChange={(e) => handleChange(q.questions_id, e.target.value)}
                                className="w-full p-3 border border-slate-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                                placeholder="คำตอบของคุณ"
                                required
                            />
                        )}
                    </div>
                ))}
                <div className="flex justify-end space-x-4 mt-8">
                    <button
                        type="button"
                        onClick={onBack}
                        className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-6 rounded-lg"
                    >
                        ย้อนกลับ
                    </button>
                    <button
                        type="submit"
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg"
                    >
                        ส่ง
                    </button>
                </div>
            </form>
        </div>
    );
};

// =============================================================================
// ==== COMPONENT: ADMIN ROLE ==================================================
// =============================================================================
const AddSurveyModal = ({ isOpen, onClose, onSave, projects }) => {
    const [selectedProject, setSelectedProject] = useState('');

    useEffect(() => {
        if (!isOpen) {
            setSelectedProject('');
        }
    }, [isOpen]);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (selectedProject) {
            onSave(selectedProject);
            onClose();
        } else {
            Swal.fire('Warning', 'Please select a project.', 'warning');
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-lg p-6">
                <h3 className="text-xl font-semibold mb-4">สร้างแบบประเมินใหม่</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700">เลือกโครงการ</label>
                        <select
                            value={selectedProject}
                            onChange={(e) => setSelectedProject(e.target.value)}
                            className="mt-1 block w-full border-slate-300 rounded-md shadow-sm p-2"
                            required
                        >
                            <option value="">-- เลือกโครงการ --</option>
                            {projects.map(p => (
                                <option key={p.project_id} value={p.project_id}>
                                    {p.project_title}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="flex justify-end pt-4 border-t">
                        <button
                            type="button"
                            onClick={onClose}
                            className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg mr-2"
                        >
                            ยกเลิก
                        </button>
                        <button
                            type="submit"
                            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg"
                        >
                            สร้าง
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const QuestionModal = ({ isOpen, onClose, onSave, question, assessmentId }) => {
    const [questionName, setQuestionName] = useState('');
    const [questionType, setQuestionType] = useState('complacence');

    useEffect(() => {
        if (question) {
            setQuestionName(question.questions_name);
            setQuestionType(question.question_type);
        } else {
            setQuestionName('');
            setQuestionType('complacence');
        }
    }, [isOpen, question]);

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave({
            questions_id: question?.questions_id,
            questions_name: questionName,
            question_type: questionType,
            assessment_id: assessmentId,
        });
        // onSave() จะจัดการการปิด Modal และ SweetAlert เอง
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-lg p-6">
                <h3 className="text-xl font-semibold mb-4">{question ? 'แก้ไขหัวข้อประเมิน' : 'เพิ่มหัวข้อประเมิน'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700">หัวข้อการประเมิน</label>
                        <input
                            type="text"
                            value={questionName}
                            onChange={(e) => setQuestionName(e.target.value)}
                            className="mt-1 block w-full border-slate-300 rounded-md shadow-sm p-2"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700">ประเภทคำถาม</label>
                        <div className="mt-2 space-y-2">
                            <label className="inline-flex items-center">
                                <input
                                    type="radio"
                                    value="complacence"
                                    checked={questionType === 'complacence'}
                                    onChange={() => setQuestionType('complacence')}
                                    className="form-radio h-4 w-4 text-blue-600"
                                />
                                <span className="ml-2">ประเมินความพึงพอใจ (คะแนน)</span>
                            </label>
                            <label className="inline-flex items-center ml-4">
                                <input
                                    type="radio"
                                    value="suggestions"
                                    checked={questionType === 'suggestions'}
                                    onChange={() => setQuestionType('suggestions')}
                                    className="form-radio h-4 w-4 text-blue-600"
                                />
                                <span className="ml-2">ข้อความ</span>
                            </label>
                        </div>
                    </div>
                    <div className="flex justify-end pt-4 border-t">
                        <button
                            type="button"
                            onClick={onClose}
                            className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg mr-2"
                        >
                            ยกเลิก
                        </button>
                        <button
                            type="submit"
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg"
                        >
                            {question ? 'บันทึก' : 'โพสต์'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const AdminManageSurvey = ({ assessment, onBack, onQuestionSaved }) => {
    const [questions, setQuestions] = useState([]);
    const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);
    const [selectedQuestion, setSelectedQuestion] = useState(null);

    const fetchQuestions = async () => {
        const mockQuestions = MOCK_DATA.ADMIN_QUESTIONS[assessment.assessment_id] || [];
        setQuestions(mockQuestions);
    };

    useEffect(() => {
        fetchQuestions();
    }, [assessment]);

    // **แก้ไข: ฟังก์ชันนี้จะจัดการ SweetAlert และเรียก onQuestionSaved ที่ส่งมาจาก parent**
    const handleSaveQuestion = (data) => {
        Swal.fire({
            title: 'สำเร็จ!',
            text: 'ฟังก์ชันนี้ทำงานด้วยข้อมูลจำลอง (ยังไม่บันทึก)',
            icon: 'success',
            confirmButtonText: 'ตกลง'
        }).then(() => {
            // โค้ดนี้จะทำงานเมื่อผู้ใช้กด "ตกลง"
            setIsQuestionModalOpen(false); // ปิด modal
            onQuestionSaved(); // เรียกฟังก์ชันที่ส่งมาจาก ComplacenceClientPage เพื่อเปลี่ยนหน้า
        });
    };

    const handleDeleteQuestion = (questionId) => {
        Swal.fire({
            title: 'ยืนยันการลบ?',
            text: 'ฟังก์ชันนี้ทำงานด้วยข้อมูลจำลอง (ยังไม่ลบ)',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'ลบ',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire('Success', 'ฟังก์ชันนี้ทำงานด้วยข้อมูลจำลอง (ยังไม่ลบ)', 'success');
                // ในโค้ดจริง, หลัง delete สำเร็จ ควรเรียก fetchQuestions() อีกครั้ง
                // fetchQuestions();
            }
        });
    };

    const openEditModal = (question) => {
        setSelectedQuestion(question);
        setIsQuestionModalOpen(true);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800">
                    {`แบบประเมินโครงการ ${assessment.project_name}`}
                </h2>
                <button
                    onClick={() => { setSelectedQuestion(null); setIsQuestionModalOpen(true); }}
                    className="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg"
                >
                    <FaPlus className="mr-2" />เพิ่มหัวข้อ
                </button>
            </div>
            <div className="space-y-6">
                {questions.map((q, index) => (
                    <div key={q.questions_id} className="bg-white rounded-xl shadow-md p-6 relative">
                        <div className="absolute top-4 right-4 flex space-x-2">
                            <button
                                onClick={() => openEditModal(q)}
                                className="text-slate-500 hover:text-sky-600 p-2 rounded-md"
                                title="แก้ไข"
                            >
                                <FaPenSquare />
                            </button>
                            <button
                                onClick={() => handleDeleteQuestion(q.questions_id)}
                                className="text-slate-500 hover:text-red-600 p-2 rounded-md"
                                title="ลบ"
                            >
                                <FaTrash />
                            </button>
                        </div>
                        <h4 className="text-xl font-semibold text-slate-700 mb-2">
                            {`${index + 1}. ${q.questions_name}`}
                        </h4>
                        <p className="text-sm text-slate-500">
                            ประเภท: {q.question_type === 'complacence' ? 'ประเมินความพึงพอใจ (คะแนน)' : 'ข้อเสนอแนะ (ข้อความ)'}
                        </p>
                    </div>
                ))}
            </div>
            <div className="flex justify-end pt-8 mt-4 border-t space-x-4">
                <button
                    onClick={onBack}
                    className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-6 rounded-lg"
                >
                    ย้อนกลับ
                </button>
                <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg"
                >
                    บันทึก
                </button>
            </div>
            <QuestionModal
                isOpen={isQuestionModalOpen}
                onClose={() => setIsQuestionModalOpen(false)}
                onSave={handleSaveQuestion}
                question={selectedQuestion}
                assessmentId={assessment.assessment_id}
            />
        </div>
    );
};

const AdminSurveyList = ({ assessments, onManage, onToggleStatus, onAdd }) => {
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800">แบบประเมิน</h2>
                <button
                    onClick={onAdd}
                    className="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg"
                >
                    <FaPlus className="mr-2" />เพิ่มแบบประเมิน
                </button>
            </div>
            {assessments.length === 0 ? (
                <div className="text-center p-10"><p>ไม่พบข้อมูลแบบประเมิน</p></div>
            ) : (
                assessments.map(a => (
                    <div key={a.assessment_id} className="bg-white rounded-xl shadow-md p-6 flex justify-between items-center">
                        <div className="flex-grow">
                            <h4 className="text-xl font-semibold text-slate-700">
                                {`แบบประเมินโครงการ ${a.project_name}`}
                            </h4>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                                <span className="text-sm text-slate-500">สถานะ: {a.evaluation_status === 'active' ? 'เปิด' : 'ปิด'}</span>
                                <label className="flex items-center cursor-pointer">
                                    <div className="relative">
                                        <input
                                            type="checkbox"
                                            className="sr-only"
                                            checked={a.evaluation_status === 'active'}
                                            onChange={() => onToggleStatus(a.assessment_id, a.evaluation_status)}
                                        />
                                        <div className={`block bg-gray-200 w-14 h-8 rounded-full transition-all duration-300 ${a.evaluation_status === 'active' ? 'bg-green-500' : ''}`}></div>
                                        <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-all duration-300 ${a.evaluation_status === 'active' ? 'translate-x-full' : ''}`}></div>
                                    </div>
                                </label>
                            </div>
                            <button
                                onClick={() => onManage(a)}
                                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg"
                            >
                                จัดการ
                            </button>
                        </div>
                    </div>
                ))
            )}
        </div>
    );
};

// =============================================================================
// ==== MAIN PAGE COMPONENT ====================================================
// =============================================================================

export default function ComplacenceClientPage() {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [userRole, setUserRole] = useState(null);

    // State for Admin
    const [assessments, setAssessments] = useState([]);
    const [allProjects, setAllProjects] = useState([]);
    const [currentAdminView, setCurrentAdminView] = useState('list'); // 'list' | 'manage'
    const [selectedAssessment, setSelectedAssessment] = useState(null);
    const [isAddSurveyModalOpen, setIsAddSurveyModalOpen] = useState(false);

    // State for Student
    const [studentProjects, setStudentProjects] = useState([]);
    const [currentStudentView, setCurrentStudentView] = useState('list'); // 'list' | 'form'
    const [selectedSurvey, setSelectedSurvey] = useState(null);
    const [isCompletionModalOpen, setIsCompletionModalOpen] = useState(false);

    const resetStudentState = () => {
        setStudentProjects(MOCK_DATA.STUDENT_PROJECTS); // รีเซ็ต studentProjects
        setCurrentStudentView('list');
        setSelectedSurvey(null);
    };

    const resetAdminState = () => {
        setAssessments([]);
        setAllProjects([]);
        setCurrentAdminView('list');
        setSelectedAssessment(null);
        setIsAddSurveyModalOpen(false);
    };

    // **เพิ่ม: ฟังก์ชันสำหรับเปลี่ยนหน้าจอ Admin กลับไปหน้าหลัก**
    const handleSaveAndClose = () => {
        setCurrentAdminView('list');
        fetchData();
    };

    const fetchData = async () => {
        setLoading(true);
        setError(null);
        const userData = { role_id: 1, std_id: '6521651170' }; // เปลี่ยน role_id เป็น 2 เพื่อทดสอบ Admin View
        const user = userData;
        setCurrentUser(user);
        setUserRole(user.role_id);

        await new Promise(resolve => setTimeout(resolve, 500));

        try {
            if (user.role_id === 1) { // Student
                resetAdminState();
                setStudentProjects(MOCK_DATA.STUDENT_PROJECTS);
            } else if (user.role_id === 2 || user.role_id === 3) { // Admin/Staff
                resetStudentState();
                setAssessments(MOCK_DATA.ADMIN_ASSESSMENTS);
                setAllProjects(MOCK_DATA.ADMIN_PROJECTS);
            }
        } catch (err) {
            setError('Failed to fetch mock data.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleStartSurvey = async (assessmentId) => {
        setLoading(true);
        await new Promise(resolve => setTimeout(resolve, 300));
        const surveyDetails = MOCK_DATA.SURVEY_DETAILS[assessmentId];
        setSelectedSurvey(surveyDetails);
        setCurrentStudentView('form');
        setLoading(false);
    };

    const handleStudentSurveySubmit = async (assessmentId, answers) => {
        console.log('Submitted answers:', answers);
        await new Promise(resolve => setTimeout(resolve, 300));
        Swal.fire('Success', 'ฟังก์ชันนี้ทำงานด้วยข้อมูลจำลอง (ยังไม่บันทึก)', 'success');
        setIsCompletionModalOpen(true);
    };

    const handleCloseCompletionModal = () => {
        setIsCompletionModalOpen(false);
        resetStudentState();
    };

    const handleToggleStatus = async (assessmentId, currentStatus) => {
        const newStatus = currentStatus === 'active' ? 'unused' : 'active';
        console.log(`Toggling status for assessment ${assessmentId} to ${newStatus}`);
        await new Promise(resolve => setTimeout(resolve, 300));
        Swal.fire('Success', 'ฟังก์ชันนี้ทำงานด้วยข้อมูลจำลอง (ยังไม่บันทึก)', 'success');
        fetchData();
    };

    const handleCreateAssessment = async (projectId) => {
        console.log(`Creating assessment for project ${projectId}`);
        await new Promise(resolve => setTimeout(resolve, 300));
        Swal.fire('Success', 'ฟังก์ชันนี้ทำงานด้วยข้อมูลจำลอง (ยังไม่สร้าง)', 'success');
    };

    if (loading) {
        return <div className="text-center p-10"><p>Loading...</p></div>;
    }

    if (error) {
        return <div className="text-center p-10 text-red-500"><FaExclamationCircle className="mx-auto text-4xl mb-2" /><p>{error}</p></div>;
    }

    if (userRole === 1) { // Student View
        return (
            <div className="bg-gray-100 min-h-screen p-4 sm:p-6 lg:p-8">
                <div className="max-w-7xl mx-auto">
                    {currentStudentView === 'list' && (
                        <div>
                            <h1 className="text-3xl font-bold text-gray-800 mb-6">แบบประเมินโครงการ</h1>
                            <div className="space-y-6">
                                {studentProjects.length === 0 ? (
                                    <div className="text-center p-10"><p>ไม่พบแบบประเมินที่ต้องทำ</p></div>
                                ) : (
                                    studentProjects.map(p => (
                                        <div key={p.project_id} className="bg-white rounded-xl shadow-md p-6 flex justify-between items-center">
                                            <h4 className="text-xl font-semibold text-slate-700">
                                                {`โครงการ ${p.project_title}`}
                                            </h4>
                                            <button
                                                onClick={() => handleStartSurvey(p.assessment_id)}
                                                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg"
                                            >
                                                เริ่มทำ
                                            </button>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    )}
                    {currentStudentView === 'form' && (
                        <StudentSurveyForm
                            survey={selectedSurvey}
                            onBack={() => {
                                setCurrentStudentView('list');
                                setSelectedSurvey(null);
                            }}
                            onSubmit={handleStudentSurveySubmit}
                        />
                    )}
                </div>
            </div>
        );
    } else if (userRole === 2 || userRole === 3) { // Admin/Staff View
        return (
            <div className="bg-gray-100 min-h-screen p-4 sm:p-6 lg:p-8">
                <div className="max-w-7xl mx-auto">
                    {currentAdminView === 'list' && (
                        <AdminSurveyList
                            assessments={assessments}
                            onManage={(assessment) => { setSelectedAssessment(assessment); setCurrentAdminView('manage'); }}
                            onToggleStatus={handleToggleStatus}
                            onAdd={() => setIsAddSurveyModalOpen(true)}
                        />
                    )}
                    {currentAdminView === 'manage' && (
                        <AdminManageSurvey
                            assessment={selectedAssessment}
                            onBack={() => {
                                setCurrentAdminView('list');
                                setSelectedAssessment(null);
                            }}
                            onQuestionSaved={handleSaveAndClose} // <-- ใช้ฟังก์ชันที่เพิ่มเข้ามา
                        />
                    )}
                </div>
                <AddSurveyModal
                    isOpen={isAddSurveyModalOpen}
                    onClose={() => setIsAddSurveyModalOpen(false)}
                    onSave={handleCreateAssessment}
                    projects={allProjects}
                />
            </div>
        );
    }

    return null;
}