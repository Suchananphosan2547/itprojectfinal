import ProjectClientPage from './ProjectClientPage';

export default function ProjectPage() {
  return (
    <ProjectClientPage />
  );
}