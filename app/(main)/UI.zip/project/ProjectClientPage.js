'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { FaRegSquarePlus, FaTriangleExclamation, FaCircleInfo, FaPenToSquare, FaTrash, FaUserTie, FaCalendarDays, FaClock, FaCalendarXmark, FaCircleCheck, FaUsers, FaUserPlus, FaFloppyDisk, FaFile, FaPaperclip } from 'react-icons/fa6';
import * as XLSX from 'xlsx';
import Cookies from 'js-cookie';


// Mock Data (จำลองข้อมูลจากฐานข้อมูลเพื่อการทดสอบ)
export const MOCK_PROJECTS = [
  {
    project_id: 1,
    project_title: 'โครงการอบรมเชิงปฏิบัติการพัฒนาทักษะการเขียนโปรแกรมด้วยภาษา Python',
    project_description: 'มุ่งเน้นการสอนพื้นฐานการเขียนโปรแกรมด้วยภาษา Python สำหรับนิสิตที่ไม่มีพื้นฐาน เพื่อนำไปประยุกต์ใช้ในการเรียนและการทำงานในอนาคต',
    program_type: 'ปกติ',
    create_date: '2025-08-15T10:00:00Z',
    start_project: '2025-09-01T09:00:00Z',
    end_project: '2025-09-02T17:00:00Z',
    program_location: 'อาคารเรียนรวม 1 ห้อง 101',
    registration_status: 'active',
    create_by: 'บุคลากร1',
    manager_id: 1,
    responsible_teacher: 'อาจารย์ ภัทราพร',
    associated_budget: 15000,
    fiscal_year: 2568,
    group_count: 50,
    expected_participant_percentage: 80,
    plan_detail: 'แผนงานเพื่อพัฒนาทักษะด้านดิจิทัลสำหรับนิสิต',
    objectives: [
      'เพื่อให้นิสิตมีความรู้ความเข้าใจพื้นฐานเกี่ยวกับการเขียนโปรแกรมภาษา Python',
      'เพื่อให้นิสิตสามารถนำความรู้ไปใช้ในการสร้างสรรค์โปรเจกต์ขนาดเล็กได้',
    ],
    attached_file_name: 'Python_Workshop_Plan.pdf',
    attached_file_url: '/assets/files/Python_Workshop_Plan.pdf',
  },
  {
    project_id: 2,
    project_title: 'โครงการจิตอาสาทำความสะอาดชุมชน',
    project_description: 'กิจกรรมจิตอาสาเพื่อสร้างจิตสำนึกที่ดีแก่สังคม โดยร่วมกันทำความสะอาดและปรับปรุงภูมิทัศน์ของชุมชนใกล้เคียงมหาวิทยาลัย',
    program_type: 'ปกติ',
    create_date: '2025-08-10T12:00:00Z',
    start_project: '2025-08-25T08:00:00Z',
    end_project: '2025-08-25T12:00:00Z',
    program_location: 'ชุมชนหน้ามหาวิทยาลัย',
    registration_status: 'active',
    create_by: 'บุคลากร2',
    manager_id: 2,
    responsible_teacher: 'อาจารย์ ชัยวัฒน์',
    associated_budget: null,
    fiscal_year: 2568,
    group_count: 30,
    expected_participant_percentage: 100,
    plan_detail: 'แผนงานส่งเสริมกิจกรรมเพื่อสังคม',
    objectives: [
      'เพื่อให้นิสิตได้มีส่วนร่วมในกิจกรรมที่เป็นประโยชน์ต่อสังคม',
      'เพื่อส่งเสริมความสามัคคีและการทำงานร่วมกันเป็นทีม',
    ],
    attached_file_name: 'Community_Service_Details.docx',
    attached_file_url: '/assets/files/Community_Service_Details.docx',
  },
  {
    project_id: 3,
    project_title: 'สัมมนาวิชาการเรื่อง "เทคโนโลยี AI กับการเปลี่ยนแปลงโลก"',
    project_description: 'เจาะลึกบทบาทของปัญญาประดิษฐ์ในอุตสาหกรรมต่างๆ และการเตรียมความพร้อมสำหรับอาชีพในยุคดิจิทัล',
    program_type: 'พิเศษ',
    create_date: '2025-08-05T09:30:00Z',
    start_project: '2025-10-10T13:00:00Z',
    end_project: '2025-10-10T17:00:00Z',
    program_location: 'หอประชุมใหญ่',
    registration_status: 'inactive',
    create_by: 'บุคลากร3',
    manager_id: 3,
    responsible_teacher: 'อาจารย์ วรรณภา',
    associated_budget: 30000,
    fiscal_year: 2568,
    group_count: 150,
    expected_participant_percentage: 75,
    plan_detail: 'แผนงานเพื่อเพิ่มพูนความรู้ด้านเทคโนโลยี',
    objectives: [
      'เพื่อให้นิสิตได้อัปเดตความรู้เกี่ยวกับเทรนด์เทคโนโลยี AI ล่าสุด',
      'เพื่อสร้างแรงบันดาลใจในการศึกษาและประกอบอาชีพในสาขาที่เกี่ยวข้อง',
    ],
    attached_file_name: null, // ไม่มีไฟล์แนบ
    attached_file_url: null,
  },
  {
    project_id: 3,
    project_title: 'โครงการศึกษาการตลาดออนไลน์',
    project_description: 'ศึกษาและวิเคราะห์พฤติกรรมผู้บริโภคในยุคดิจิทัล',
    project_detail: 'โครงการนี้จะเปิดรับนิสิตภาคปกติและภาคพิเศษเข้าร่วม',
    program_type: 'ปกติ',
    associated_budget: 80000,
    group_count: 100,
    plan_quality: 0.7,
    plan_detail: 'แผนงาน 1',
    program_location: 'อาคารเรียนรวม 2',
    create_by: 'admin',
    create_date: '2025-07-20T11:00:00Z',
    start_project: '2025-08-15T13:00:00',
    end_project: '2025-08-04T12:00:00',
    registration_status: 'active',
    firstname: 'แอดมิน',
    lastname: 'ระบบ',
    manager_id: 'manager1',
    objectives: ['เก็บข้อมูลลูกค้า', 'วิเคราะห์เทรนด์การตลาด', 'สรุปผลและนำเสนอ']
  },
];

const MOCK_REGISTRATIONS = [
  { registration_id: 2, project_id: 1, std_id: '6522222222', registered_at: '2025-08-02T11:00:00Z', firstname: 'สมหญิง', lastname: 'มีสุข', allergies: '', suggestions: '' },
  { registration_id: 3, project_id: 1, std_id: '6533333333', registered_at: '2025-08-02T12:00:00Z', firstname: 'ชัยชนะ', lastname: 'เป็นหนึ่ง', allergies: 'แพ้อาหารทะเล', suggestions: 'ขอเมนูมังสวิรัติ' },
];

const MOCK_USERS = [
  { std_id: '6511111111', username: 'student_normal', role_id: 1, program_type: 'ปกติ', firstname: 'สมชาย', lastname: 'ใจดี' },
  { std_id: '6522222222', username: 'student_special', role_id: 1, program_type: 'พิเศษ', firstname: 'สมหญิง', lastname: 'มีสุข' },
  { std_id: 'manager', username: 'manager', role_id: 2, program_type: 'ปกติ', firstname: 'ผู้จัดการ', lastname: 'โครงการ' },
  { std_id: 'admin', username: 'admin', role_id: 3, program_type: 'ปกติ', firstname: 'แอดมิน', lastname: 'ระบบ' },
];

const MOCK_TEACHERS = [
  { manager_id: 'manager1', firstname: 'อาจารย์', lastname: 'หนึ่ง' },
  { manager_id: 'teacher1', firstname: 'อาจารย์', lastname: 'สอง' },
  { manager_id: 'teacher2', firstname: 'อาจารย์', lastname: 'สาม' },
];

const SortIcon = ({ sortField, currentSortField, sortOrder }) => {
  if (sortField !== currentSortField) {
    return <FaSort className="text-slate-400" />;
  }
  return sortOrder === 'asc' ? <FaSortUp /> : <FaSortDown />;
};

// --- Component สำหรับแสดงผลการ์ดโครงการ ---
const ProjectCard = ({ project, currentUser, onEdit, onDelete, onViewDetails, isRegistered }) => {
  const creatorName = (project.firstname && project.lastname) ? `${project.firstname} ${project.lastname}` : project.create_by;
  const formattedDate = new Date(project.create_date).toLocaleString('th-TH', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const canModify = currentUser && (currentUser.role_id === 3 || currentUser.role_id === 2);
  const isStudent = currentUser && currentUser.role_id === 1;
  const isRegistrationActive = project.registration_status === 'active' && new Date(project.end_project) >= new Date();
  const isProjectOverdue = new Date(project.end_project) < new Date();

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transform hover:-translate-y-1 transition-all duration-300 relative">
      <div className="flex justify-end items-center absolute top-4 right-4 space-x-2">
        {canModify && (
          <div className="flex space-x-2">
            <button onClick={() => onEdit(project)} className="edit-btn text-slate-500 hover:text-sky-600 p-2 rounded-md" title="Edit"><FaPenToSquare /></button>
            <button onClick={() => onDelete(project.project_id)} className="delete-btn text-slate-500 hover:text-red-600 p-2 rounded-md" title="Delete"><FaTrash /></button>
          </div>
        )}
      </div>

      <div className="p-6 pt-16">
        <h3 className="text-2xl font-bold text-slate-800 mb-3 pr-24">{project.project_title}</h3>
        <div className="flex items-center space-x-3 text-sm text-slate-500 mb-4 border-b border-slate-200 pb-4">
          <FaUserTie className="h-4 w-4 mr-1.5" /><span>By: {creatorName}</span>
          <FaCalendarDays className="h-4 w-4 mr-1.5" /><span>{formattedDate}</span>
          <div className={`text-xs font-bold px-2 py-1 rounded-full text-white ${project.program_type === 'ปกติ' ? 'bg-indigo-500' : 'bg-pink-500'}`}>
            <span>{project.program_type}</span>
          </div>
        </div>
        <p className="text-slate-600 mb-6 leading-relaxed">{project.project_description}</p>

        <div className="flex items-center space-x-2 mt-4">
          {project.attached_file_name && (
            <a href={project.attached_file_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800 transition-colors duration-200">
              <FaPaperclip className="mr-1.5" />
              <span>{project.attached_file_name}</span>
            </a>
          )}
        </div>

        <div className="flex items-center justify-between flex-wrap">
          <div className="flex items-center space-x-2 text-sm text-slate-500 mb-2 md:mb-0">
            {isProjectOverdue ? (
              <div className="text-red-600 flex items-center font-semibold"><FaCalendarXmark className="mr-2" />หมดเขตลงทะเบียนแล้ว</div>
            ) : (
              <div className="text-green-600 flex items-center font-semibold"><FaClock className="mr-2" />เปิดรับลงทะเบียนถึง: {new Date(project.end_project).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' })}</div>
            )}
          </div>
          <div className="flex space-x-2 mt-2 md:mt-0">
            {isStudent && isRegistrationActive && (
              isRegistered ? (
                <span className="inline-flex items-center px-4 py-2 bg-green-100 text-green-700 font-semibold rounded-lg">
                  <FaCircleCheck className="mr-2" />ลงทะเบียนแล้ว
                </span>
              ) : (
                <button onClick={() => onViewDetails(project)} className="inline-flex items-center px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold rounded-lg shadow-md">
                  <FaUsers className="mr-2" />ดูรายละเอียด
                </button>
              )
            )}
            {isStudent && !isRegistrationActive && (
              <button onClick={() => onViewDetails(project)} className="inline-flex items-center px-4 py-2 bg-slate-200 text-slate-500 font-semibold rounded-lg shadow-md" disabled>
                <FaUsers className="mr-2" />ปิดรับลงทะเบียน
              </button>
            )}
            {canModify && (
              <button onClick={() => onViewDetails(project)} className="inline-flex items-center px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold rounded-lg shadow-md">
                <FaUsers className="mr-2" />ดูรายละเอียด
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Component ใหม่: Popup แสดงรายละเอียดโครงการ (ปรับปรุงตาม Role) ---
const ProjectDetailsModal = ({ isOpen, onClose, projectItem, onViewRegistrations, onOpenRegisterForm, onUnregister, isRegistered, isStudent }) => {
  if (!isOpen || !projectItem) return null;

  // หาชื่อผู้สร้างโครงการจาก create_by (ถ้ามี) หรือใช้ MOCK_TEACHERS ถ้าเป็น manager_id
  const creatorName = (projectItem.firstname && projectItem.lastname) ? `${projectItem.firstname} ${projectItem.lastname}` : projectItem.create_by;
  // หาชื่ออาจารย์ผู้รับผิดชอบ
  const teacherName = MOCK_TEACHERS.find(t => t.manager_id === projectItem.manager_id);
  const formattedStartDate = new Date(projectItem.start_project).toLocaleString('th-TH', { dateStyle: 'long', timeStyle: 'short' });
  const formattedEndDate = new Date(projectItem.end_project).toLocaleString('th-TH', { dateStyle: 'long', timeStyle: 'short' });
  const isRegistrationActive = projectItem.registration_status === 'active' && new Date(projectItem.end_project) >= new Date();

  return (
    <div className="modal fixed inset-0 z-50 flex items-center justify-center">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h3 className="text-2xl font-bold">รายละเอียดโครงการ</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 text-3xl leading-none">&times;</button>
        </div>
        <div className="space-y-4 text-slate-700">
          <h4 className="text-xl font-semibold">{projectItem.project_title}</h4>
          <p className="text-slate-500">{projectItem.project_description}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="font-semibold">ช่วงเวลา:</p>
              <p>ตั้งแต่ {formattedStartDate} ถึง {formattedEndDate}</p>
            </div>
            <div>
              <p className="font-semibold">สถานที่:</p>
              <p>{projectItem.program_location || '-'}</p>
            </div>
            {/* ส่วนนี้จะแสดงผลเฉพาะสำหรับ Role 2 (บุคลากร) ขึ้นไป */}
            {!isStudent && (
              <>
                <div>
                  <p className="font-semibold">ผู้รับผิดชอบ:</p>
                  <p>{teacherName ? `${teacherName.firstname} ${teacherName.lastname}` : creatorName}</p>
                </div>
                <div>
                  <p className="font-semibold">ภาค:</p>
                  <p>{projectItem.program_type || '-'}</p>
                </div>
                <div>
                  <p className="font-semibold">งบประมาณ:</p>
                  <p>{projectItem.associated_budget ? projectItem.associated_budget.toLocaleString('th-TH') + ' บาท' : '-'}</p>
                </div>
                <div>
                  <p className="font-semibold">ปีงบประมาณ:</p>
                  <p>{projectItem.fiscal_year || '-'}</p>
                </div>
                <div>
                  <p className="font-semibold">จำนวนกลุ่มเป้าหมาย:</p>
                  <p>{projectItem.group_count ? `${projectItem.group_count} คน` : '-'}</p>
                </div>
                <div>
                  <p className="font-semibold">เปอร์เซ็นต์ที่คาดว่าจะเข้าร่วม:</p>
                  <p>{projectItem.expected_participant_percentage ? `${projectItem.expected_participant_percentage} %` : '-'}</p>
                </div>
                <div>
                  <p className="font-semibold">แผนงาน:</p>
                  <p>{projectItem.plan || '-'}</p>
                </div>
                <div>
                  <p className="font-semibold">สถานะการลงทะเบียน:</p>
                  <p className={`font-medium ${projectItem.registration_status === 'active' ? 'text-green-600' : 'text-red-600'}`}>
                    {projectItem.registration_status === 'active' ? 'เปิดรับ' : 'ปิดรับ'}
                  </p>
                </div>
              </>
            )}
          </div>

          {/* วัตถุประสงค์ (แสดงผลเฉพาะสำหรับ Role 2 ขึ้นไป) */}
          {!isStudent && (
            <div className="pt-4">
              <h5 className="font-semibold text-lg">วัตถุประสงค์:</h5>
              <ul className="list-disc list-inside space-y-1">
                {projectItem.objectives?.length > 0 ? (
                  projectItem.objectives.map((obj, index) => (
                    <li key={index}>{obj}</li>
                  ))
                ) : (
                  <li>-</li>
                )}
              </ul>
            </div>
          )}

          {projectItem.attached_file_name && (
            <div>
              <p className="font-semibold">ไฟล์แนบ:</p>
              <a href={projectItem.attached_file_url} target="_blank" rel="noopener noreferrer" className="flex items-center text-blue-600 hover:text-blue-800 transition-colors duration-200 mt-1">
                <FaFile className="mr-2" />
                <span>{projectItem.attached_file_name}</span>
              </a>
            </div>
          )}
        </div>

        <div className="flex justify-end pt-5 mt-4 border-t">
          {/* ปุ่มสำหรับผู้ดูแล/อาจารย์ */}
          {!isStudent && (
            <button onClick={() => onViewRegistrations(projectItem.project_id)} className="bg-sky-600 hover:bg-sky-700 text-white font-bold py-2 px-4 rounded-lg mr-3">
              <FaUsers className="inline-block mr-2" />ดูข้อมูลการลงทะเบียน
            </button>
          )}

          {/* ปุ่มสำหรับนิสิต */}
          {isStudent && isRegistrationActive && (
            isRegistered ? (
              <button onClick={() => onUnregister(projectItem.project_id)} className="inline-flex items-center px-4 py-2 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg shadow-md mr-3">
                <FaUserPlus className="mr-2" />ยกเลิกการลงทะเบียน
              </button>
            ) : (
              <button onClick={() => onOpenRegisterForm(projectItem)} className="inline-flex items-center px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg shadow-md mr-3">
                <FaUserPlus className="mr-2" />ลงทะเบียนเข้าร่วม
              </button>
            )
          )}

          <button onClick={onClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg">ปิด</button>
        </div>
      </div>
    </div>
  );
};


// --- Component สำหรับ Modal ยืนยันการลงทะเบียนพร้อมฟอร์ม ---
const RegistrationConfirmationModal = ({ isOpen, onClose, onConfirm, projectItem }) => {
  const [allergyOption, setAllergyOption] = useState('none');
  const [allergyText, setAllergyText] = useState('');
  const [suggestions, setSuggestions] = useState('');
  const formattedDates = `${new Date(projectItem?.start_project).toLocaleDateString('th-TH')} - ${new Date(projectItem?.end_project).toLocaleDateString('th-TH')}`;

  if (!isOpen || !projectItem) return null;

  const handleConfirm = () => {
    const allergyData = allergyOption === 'has' ? allergyText : '';
    onConfirm(projectItem.project_id, allergyData, suggestions);
  };

  return (
    <div className="modal fixed inset-0 z-50 flex items-center justify-center">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h3 className="text-2xl font-bold">ลงทะเบียนเข้าร่วม</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 text-3xl leading-none">&times;</button>
        </div>

        <div className="space-y-4 text-slate-700">
          <div className="p-4 border border-gray-200 rounded-lg bg-gray-50">
            <h4 className="text-xl font-semibold">{projectItem.project_title}</h4>
            <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
              <p><strong>สถานที่:</strong> {projectItem.program_location}</p>
              <p><strong>วันที่:</strong> {formattedDates}</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">ข้อมูลการแพ้ยา/อาหาร</label>
            <div className="flex space-x-4">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="allergy"
                  value="none"
                  checked={allergyOption === 'none'}
                  onChange={() => setAllergyOption('none')}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">ไม่มี</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="allergy"
                  value="has"
                  checked={allergyOption === 'has'}
                  onChange={() => setAllergyOption('has')}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">มี</span>
              </label>
            </div>
            {allergyOption === 'has' && (
              <input
                type="text"
                placeholder="ระบุ เช่น แพ้กุ้ง, แพ้ถั่ว"
                value={allergyText}
                onChange={(e) => setAllergyText(e.target.value)}
                className="w-full border-slate-300 rounded-md shadow-sm p-2 mt-2"
              />
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700">ข้อมูลเสนอแนะเพิ่มเติม</label>
            <textarea
              rows="3"
              value={suggestions}
              onChange={(e) => setSuggestions(e.target.value)}
              className="w-full border-slate-300 rounded-md shadow-sm p-2 mt-1"
              placeholder="กรอกข้อมูลที่ต้องการแจ้งให้ทราบเพิ่มเติม"
            ></textarea>
          </div>
        </div>

        <div className="flex justify-end pt-5 mt-4 border-t">
          <button onClick={onClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg mr-3">ยกเลิก</button>
          <button onClick={handleConfirm} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg">
            <FaFloppyDisk className="inline-block mr-2" /> ยืนยันการลงทะเบียน
          </button>
        </div>
      </div>
    </div>
  );
};


// --- Component สำหรับ Popup ดูรายชื่อผู้ลงทะเบียน (ปรับปรุงแล้ว) ---
const ViewParticipantsModal = ({ isOpen, onClose, participants }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: 'registered_at', direction: 'desc' });

  const sortedParticipants = useMemo(() => {
    let sortableItems = [...participants];
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [participants, sortConfig]);

  const filteredAndSortedParticipants = useMemo(() => {
    const filtered = sortedParticipants.filter(participant =>
      participant.firstname.toLowerCase().includes(searchTerm.toLowerCase()) ||
      participant.lastname.toLowerCase().includes(searchTerm.toLowerCase()) ||
      participant.std_id.includes(searchTerm)
    );
    return filtered;
  }, [searchTerm, sortedParticipants]);

  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return <FaSort className="text-slate-400" />;
    return sortConfig.direction === 'asc' ? <FaSortUp /> : <FaSortDown />;
  };

  if (!isOpen) return null;
  return (
    <div className="modal fixed inset-0 z-50 flex items-center justify-center">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-center p-6 border-b flex-shrink-0">
          <h3 className="text-2xl font-bold text-slate-800">รายชื่อผู้ลงทะเบียน</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 text-3xl leading-none">&times;</button>
        </div>
        <div className="p-6">
          <div className="relative mb-4">
            <input
              type="text"
              placeholder="ค้นหาด้วยชื่อหรือรหัสนิสิต"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
            <FaMagnifyingGlass className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
          </div>
        </div>
        <div className="overflow-x-auto p-6 pt-0 flex-grow">
          {filteredAndSortedParticipants.length === 0 ? (
            <div className="text-center text-slate-500 p-8">ไม่พบรายชื่อที่ค้นหา</div>
          ) : (
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer" onClick={() => requestSort('firstname')}>
                    <div className="flex items-center">
                      ชื่อ-นามสกุล <span className="ml-2">{getSortIcon('firstname')}</span>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer" onClick={() => requestSort('std_id')}>
                    <div className="flex items-center">
                      รหัสนิสิต <span className="ml-2">{getSortIcon('std_id')}</span>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer" onClick={() => requestSort('registered_at')}>
                    <div className="flex items-center">
                      วันที่ลงทะเบียน <span className="ml-2">{getSortIcon('registered_at')}</span>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ข้อมูลการแพ้</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ข้อเสนอแนะ</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredAndSortedParticipants.map((participant, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">{participant.firstname} {participant.lastname}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{participant.std_id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{new Date(participant.registered_at).toLocaleString('th-TH')}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{participant.allergies || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{participant.suggestions || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <div className="flex justify-end p-6 border-t mt-auto flex-shrink-0">
          <button onClick={onClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg">ปิด</button>
        </div>
      </div>
    </div>
  );
};


// Component สำหรับ Popup เพิ่มโครงการ
const AddProjectModal = ({ isOpen, onClose, onSave, currentUser }) => {
  const [projectTitle, setProjectTitle] = useState('');
  const [startProject, setStartProject] = useState('');
  const [endProject, setEndProject] = useState('');
  const [programPhase, setProgramPhase] = useState('');
  const [associatedBudget, setAssociatedBudget] = useState('');
  const [fiscalYear, setFiscalYear] = useState('');
  const [groupCount, setGroupCount] = useState('');
  const [expectedParticipantPercentage, setExpectedParticipantPercentage] = useState('');
  const [plan, setPlan] = useState('');
  const [programLocation, setProgramLocation] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [responsibleTeacherId, setResponsibleTeacherId] = useState('');
  const [attachedFile, setAttachedFile] = useState(null);
  const [attachedFileName, setAttachedFileName] = useState(''); // เพิ่ม state สำหรับเก็บชื่อไฟล์
  const [objectives, setObjectives] = useState(['']);
  const [error, setError] = useState('');

  const handleClose = () => {
    setError('');
    // Clear all form states when closing
    setProjectTitle('');
    setStartProject('');
    setEndProject('');
    setProgramPhase('');
    setAssociatedBudget('');
    setFiscalYear('');
    setGroupCount('');
    setExpectedParticipantPercentage('');
    setPlan('');
    setProgramLocation('');
    setProjectDescription('');
    setResponsibleTeacherId('');
    setAttachedFile(null);
    setAttachedFileName('');
    setObjectives(['']); // Reset objectives to a single empty string
    onClose();
  };

  const handleAddObjective = () => { setObjectives([...objectives, '']); };
  const handleObjectiveChange = (index, value) => { const newObjectives = [...objectives]; newObjectives[index] = value; setObjectives(newObjectives); };
  const handleRemoveObjective = (index) => { const newObjectives = objectives.filter((_, i) => i !== index); setObjectives(newObjectives); };

  // เพิ่มฟังก์ชันจัดการไฟล์
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAttachedFile(file);
      setAttachedFileName(file.name);
    }
  };

  // เพิ่มฟังก์ชันลบไฟล์ที่เลือก
  const handleRemoveFile = () => {
    setAttachedFile(null);
    setAttachedFileName('');
    // ต้องเคลียร์ค่าใน input ด้วยเพื่อรองรับการเลือกไฟล์ซ้ำ
    // This is important because if the user selects the same file again,
    // the onChange event might not fire if the input's value isn't cleared.
    const fileInput = document.getElementById('attached-file-input');
    if (fileInput) fileInput.value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    // Basic validation for required fields
    if (!projectTitle || !startProject || !endProject || !projectDescription || !responsibleTeacherId) {
      setError('Please fill in all required fields (marked with *).');
      return;
    }

    const projectData = {
      project_title: projectTitle,
      start_project: startProject,
      end_project: endProject,
      program_phase: programPhase,
      associated_budget: parseFloat(associatedBudget) || 0,
      fiscal_year: parseInt(fiscalYear) || 0,
      group_count: parseInt(groupCount) || 0,
      expected_participant_percentage: parseFloat(expectedParticipantPercentage) || 0,
      plan: plan,
      program_location: programLocation,
      project_description: projectDescription,
      manager_id: responsibleTeacherId,
      objectives: objectives.filter(obj => obj.trim() !== ''), // Filter out empty objectives
      attached_file: attachedFile,
    };
    try {
      await onSave(projectData);
      handleClose(); // Close modal on successful save
    } catch (err) {
      setError(err.message || 'Failed to add project.');
    }
  };

  if (!isOpen) return null; // Don't render if not open

  return (
    <div className="modal fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b pb-3">
          <h3 className="text-2xl font-bold">เพิ่มโครงการ</h3>
          <button onClick={handleClose} className="text-slate-400 hover:text-slate-700 text-3xl leading-none">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="mt-5 space-y-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">หัวข้อโครงการ <span className="text-red-500">*</span></label>
                <input type="text" value={projectTitle} onChange={(e) => setProjectTitle(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">เริ่ม <span className="text-red-500">*</span></label>
                <input type="datetime-local" value={startProject} onChange={(e) => setStartProject(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">สิ้นสุด <span className="text-red-500">*</span></label>
                <input type="datetime-local" value={endProject} onChange={(e) => setEndProject(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ภาค</label>
                <select value={programPhase} onChange={(e) => setProgramPhase(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2">
                  <option value="">- เลือกภาค -</option>
                  <option value="ปกติ">ปกติ</option>
                  <option value="พิเศษ">พิเศษ</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">งบประมาณที่ได้รับจัดสรร</label>
                <div className="relative">
                  <input type="number" value={associatedBudget} onChange={(e) => setAssociatedBudget(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2 pr-10" />
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500">บาท</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ปีงบประมาณ</label>
                <input type="number" value={fiscalYear} onChange={(e) => setFiscalYear(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">จำนวนกลุ่มเป้าหมาย</label>
                <input type="number" value={groupCount} onChange={(e) => setGroupCount(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">เปอร์เซ็นต์ที่คาดว่าจะเข้าร่วม</label>
                <div className="relative">
                  <input type="number" value={expectedParticipantPercentage} onChange={(e) => setExpectedParticipantPercentage(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2 pr-10" />
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500">%</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">แผนงาน</label>
                <select value={plan} onChange={(e) => setPlan(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2">
                  <option value="">- เลือกแผนงาน -</option>
                  {/* ตัวเลือกสำหรับแผนงาน */}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">การบรรลุวัตถุประสงค์</label>
                <div className="space-y-2">
                  {objectives.map((objective, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <input type="text" value={objective} onChange={(e) => handleObjectiveChange(index, e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" placeholder={`วัตถุประสงค์ข้อที่ ${index + 1}`} />
                      {objectives.length > 1 && (
                        <button type="button" onClick={() => handleRemoveObjective(index)} className="text-red-500 hover:text-red-700 p-2 text-2xl font-semibold leading-none">&times;</button>
                      )}
                    </div>
                  ))}
                  <button type="button" onClick={handleAddObjective} className="mt-2 text-sky-600 font-semibold inline-flex items-center">
                    <FaRegSquarePlus className="mr-2" />เพิ่มวัตถุประสงค์
                  </button>
                </div>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">สถานที่</label>
                <input type="text" value={programLocation} onChange={(e) => setProgramLocation(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">รายละเอียดโครงการ <span className="text-red-500">*</span></label>
                <textarea rows="3" value={projectDescription} onChange={(e) => setProjectDescription(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required></textarea>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">ชื่อผู้รับผิดชอบโครงการ <span className="text-red-500">*</span></label>
                <select value={responsibleTeacherId} onChange={(e) => setResponsibleTeacherId(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required>
                  <option value="">- เลือกอาจารย์ -</option>
                  {/* Assuming MOCK_TEACHERS is available from a shared data source or passed as prop */}
                  {/* MOCK_TEACHERS.map(teacher => (...) must be present here */}
                  {/* For demonstration, let's use a dummy teacher list if MOCK_TEACHERS is not globally available in this context */}
                  {[{ manager_id: 't1', firstname: 'อาจารย์', lastname: 'A' }, { manager_id: 't2', firstname: 'อาจารย์', lastname: 'B' }].map(teacher => (
                    <option key={teacher.manager_id} value={teacher.manager_id}>{teacher.firstname} {teacher.lastname}</option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">กรุณาแนบไฟล์</label>
                <input type="file" id="attached-file-input" onChange={handleFileChange} className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100" />
                {attachedFileName && (
                  <div className="mt-2 flex items-center space-x-2">
                    <FaFile className="text-slate-500" />
                    <p className="text-sm text-slate-700">{attachedFileName}</p>
                    <button type="button" onClick={handleRemoveFile} className="text-red-500 hover:text-red-700">
                      <FaTrash />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
          {error && <div className="text-red-600 text-sm p-3 bg-red-50 rounded-lg mt-4">{error}</div>}
          <div className="flex justify-end pt-5 mt-4 border-t">
            <button type="button" onClick={handleClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg mr-3">ยกเลิก</button>
            <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg">
              โพสต์
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Component สำหรับ Popup แก้ไขโครงการ (ปรับแก้ให้สอดคล้องกับ AddProjectModal)
const EditProjectModal = ({ isOpen, onClose, onSave, projectItem }) => {
  const [projectTitle, setProjectTitle] = useState('');
  const [startProject, setStartProject] = useState('');
  const [endProject, setEndProject] = useState('');
  const [programPhase, setProgramPhase] = useState('');
  const [associatedBudget, setAssociatedBudget] = useState('');
  const [fiscalYear, setFiscalYear] = useState('');
  const [groupCount, setGroupCount] = useState('');
  const [expectedParticipantPercentage, setExpectedParticipantPercentage] = useState('');
  const [plan, setPlan] = useState('');
  const [programLocation, setProgramLocation] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [responsibleTeacherId, setResponsibleTeacherId] = useState('');
  const [attachedFile, setAttachedFile] = useState(null);
  const [attachedFileName, setAttachedFileName] = useState(''); // เพิ่ม state สำหรับเก็บชื่อไฟล์
  const [objectives, setObjectives] = useState(['']);
  const [error, setError] = useState('');

  useEffect(() => {
    if (projectItem) {
      setProjectTitle(projectItem.project_title || '');
      setStartProject(projectItem.start_project ? new Date(projectItem.start_project).toISOString().slice(0, 16) : '');
      setEndProject(projectItem.end_project ? new Date(projectItem.end_project).toISOString().slice(0, 16) : '');
      setProgramPhase(projectItem.program_phase || '');
      setAssociatedBudget(projectItem.associated_budget || '');
      setFiscalYear(projectItem.fiscal_year || '');
      setGroupCount(projectItem.group_count || '');
      setExpectedParticipantPercentage(projectItem.expected_participant_percentage || '');
      setPlan(projectItem.plan || '');
      setProgramLocation(projectItem.program_location || '');
      setProjectDescription(projectItem.project_description || '');
      setResponsibleTeacherId(projectItem.manager_id || '');
      setObjectives(projectItem.objectives?.length > 0 ? projectItem.objectives : ['']);

      // เพิ่มการเซ็ตชื่อไฟล์เมื่อเปิด modal
      if (projectItem.attached_file_name) {
        setAttachedFileName(projectItem.attached_file_name);
      } else {
        setAttachedFileName('');
      }
    }
  }, [projectItem]);

  const handleClose = () => { setError(''); onClose(); };
  const handleAddObjective = () => { setObjectives([...objectives, '']); };
  const handleObjectiveChange = (index, value) => { const newObjectives = [...objectives]; newObjectives[index] = value; setObjectives(newObjectives); };
  const handleRemoveObjective = (index) => { const newObjectives = objectives.filter((_, i) => i !== index); setObjectives(newObjectives); };

  // เพิ่มฟังก์ชันจัดการไฟล์
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAttachedFile(file);
      setAttachedFileName(file.name);
    }
  };

  // เพิ่มฟังก์ชันลบไฟล์ที่เลือก
  const handleRemoveFile = () => {
    setAttachedFile(null);
    setAttachedFileName('');
    // ต้องเคลียร์ค่าใน input ด้วยเพื่อรองรับการเลือกไฟล์ซ้ำ
    const fileInput = document.getElementById('edit-attached-file-input');
    if (fileInput) fileInput.value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const projectData = {
      project_id: projectItem.project_id,
      project_title: projectTitle,
      start_project: startProject,
      end_project: endProject,
      program_phase: programPhase,
      associated_budget: parseFloat(associatedBudget) || 0,
      fiscal_year: parseInt(fiscalYear) || 0,
      group_count: parseInt(groupCount) || 0,
      expected_participant_percentage: parseFloat(expectedParticipantPercentage) || 0,
      plan: plan,
      program_location: programLocation,
      project_description: projectDescription,
      manager_id: responsibleTeacherId,
      objectives: objectives.filter(obj => obj.trim() !== ''),
      attached_file: attachedFile,
    };
    try { await onSave(projectData); handleClose(); } catch (err) { setError(err.message || 'Failed to update project.'); }
  };

  if (!isOpen) return null;
  return (
    <div className="modal fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b pb-3">
          <h3 className="text-2xl font-bold">แก้ไขโครงการ</h3>
          <button onClick={handleClose} className="text-slate-400 hover:text-slate-700 text-3xl leading-none">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="mt-5 space-y-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">หัวข้อโครงการ <span className="text-red-500">*</span></label>
                <input type="text" value={projectTitle} onChange={(e) => setProjectTitle(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">เริ่ม <span className="text-red-500">*</span></label>
                <input type="datetime-local" value={startProject} onChange={(e) => setStartProject(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">สิ้นสุด <span className="text-red-500">*</span></label>
                <input type="datetime-local" value={endProject} onChange={(e) => setEndProject(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ภาค</label>
                <select value={programPhase} onChange={(e) => setProgramPhase(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2">
                  <option value="">- เลือกภาค -</option>
                  <option value="ปกติ">ปกติ</option>
                  <option value="พิเศษ">พิเศษ</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">งบประมาณที่ได้รับจัดสรร</label>
                <div className="relative">
                  <input type="number" value={associatedBudget} onChange={(e) => setAssociatedBudget(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2 pr-10" />
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500">บาท</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ปีงบประมาณ</label>
                <input type="number" value={fiscalYear} onChange={(e) => setFiscalYear(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">จำนวนกลุ่มเป้าหมาย</label>
                <input type="number" value={groupCount} onChange={(e) => setGroupCount(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">เปอร์เซ็นต์ที่คาดว่าจะเข้าร่วม</label>
                <div className="relative">
                  <input type="number" value={expectedParticipantPercentage} onChange={(e) => setExpectedParticipantPercentage(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2 pr-10" />
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500">%</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">แผนงาน</label>
                <select value={plan} onChange={(e) => setPlan(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2">
                  <option value="">- เลือกแผนงาน -</option>
                  {/* ตัวเลือกสำหรับแผนงาน */}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">การบรรลุวัตถุประสงค์</label>
                <div className="space-y-2">
                  {objectives.map((objective, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <input type="text" value={objective} onChange={(e) => handleObjectiveChange(index, e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" placeholder={`วัตถุประสงค์ข้อที่ ${index + 1}`} />
                      {objectives.length > 1 && (
                        <button type="button" onClick={() => handleRemoveObjective(index)} className="text-red-500 hover:text-red-700 p-2 text-2xl font-semibold leading-none">&times;</button>
                      )}
                    </div>
                  ))}
                  <button type="button" onClick={handleAddObjective} className="mt-2 text-sky-600 font-semibold inline-flex items-center">
                    <FaRegSquarePlus className="mr-2" />เพิ่มวัตถุประสงค์
                  </button>
                </div>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">สถานที่</label>
                <input type="text" value={programLocation} onChange={(e) => setProgramLocation(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">รายละเอียดโครงการ <span className="text-red-500">*</span></label>
                <textarea rows="3" value={projectDescription} onChange={(e) => setProjectDescription(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required></textarea>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">ชื่อผู้รับผิดชอบโครงการ <span className="text-red-500">*</span></label>
                <select value={responsibleTeacherId} onChange={(e) => setResponsibleTeacherId(e.target.value)} className="w-full border-slate-300 rounded-md shadow-sm p-2" required>
                  <option value="">- เลือกอาจารย์ -</option>
                  {MOCK_TEACHERS.map(teacher => (
                    <option key={teacher.manager_id} value={teacher.manager_id}>{teacher.firstname} {teacher.lastname}</option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">กรุณาแนบไฟล์</label>
                <input type="file" id="edit-attached-file-input" onChange={handleFileChange} className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100" />
                {attachedFileName && (
                  <div className="mt-2 flex items-center space-x-2">
                    <FaFile className="text-slate-500" />
                    <p className="text-sm text-slate-700">{attachedFileName}</p>
                    <button type="button" onClick={handleRemoveFile} className="text-red-500 hover:text-red-700">
                      <FaTrash />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
          {error && <div className="text-red-600 text-sm p-3 bg-red-50 rounded-lg mt-4">{error}</div>}
          <div className="flex justify-end pt-5 mt-4 border-t">
            <button type="button" onClick={handleClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2 px-4 rounded-lg mr-3">ยกเลิก</button>
            <button type="submit" className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg">
              <FaFloppyDisk className="inline-block mr-2" /> บันทึกการแก้ไข
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export { AddProjectModal, EditProjectModal };

// --- Main Component ---
export default function ProjectClientPage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isParticipantsModalOpen, setIsParticipantsModalOpen] = useState(false);

  const [selectedProject, setSelectedProject] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [registeredProjects, setRegisteredProjects] = useState(new Set());
  const [mockRegistrations, setMockRegistrations] = useState([...MOCK_REGISTRATIONS]);

  const fetchProjects = async () => {
    setLoading(true);
    setError(null);
    try {
      const userData = MOCK_USERS[2];
      setCurrentUser(userData);
      await new Promise(resolve => setTimeout(resolve, 500));
      let fetchedProjects = MOCK_PROJECTS;
      if (userData.role_id === 1) {
        fetchedProjects = fetchedProjects.filter(p => p.program_type === userData.program_type);
      }
      setProjects(fetchedProjects);
    } catch (err) {
      setError('Failed to fetch projects.');
    } finally {
      setLoading(false);
    }
  };

  const fetchRegisteredProjects = async (stdId) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const registered = mockRegistrations.filter(reg => reg.std_id === stdId).map(reg => reg.project_id);
    setRegisteredProjects(new Set(registered));
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  useEffect(() => {
    if (currentUser?.role_id === 1) {
      fetchRegisteredProjects(currentUser.std_id);
    }
  }, [currentUser, mockRegistrations]);

  // Handle actions
  const handleAddProject = async (projectData) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      // Simulate adding file name to the mock data
      const newProject = {
        ...projectData,
        project_id: MOCK_PROJECTS.length + 1,
        attached_file_name: projectData.attached_file?.name || null,
      };
      MOCK_PROJECTS.push(newProject);
      Swal.fire('Success', 'Project created successfully!', 'success');
      fetchProjects();
    } catch (err) {
      Swal.fire('Error', 'Failed to create project.', 'error');
      throw err;
    }
  };

  const handleEditProject = async (projectData) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      // Simulate updating mock data
      const index = MOCK_PROJECTS.findIndex(p => p.project_id === projectData.project_id);
      if (index !== -1) {
        MOCK_PROJECTS[index] = {
          ...MOCK_PROJECTS[index],
          ...projectData,
          attached_file_name: projectData.attached_file?.name || MOCK_PROJECTS[index].attached_file_name,
        };
      }
      Swal.fire('Success', 'Project updated successfully!', 'success');
      fetchProjects();
    } catch (err) {
      Swal.fire('Error', 'Failed to update project.', 'error');
      throw err;
    }
  };

  const handleDeleteProject = (projectId) => {
    Swal.fire({
      title: 'Are you sure?', text: "You won't be able to revert this!", icon: 'warning', showCancelButton: true,
      confirmButtonColor: '#d33', cancelButtonColor: '#3085d6', confirmButtonText: 'Yes, delete it!', cancelButtonText: 'Cancel'
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          Swal.fire('Deleted!', 'The project has been deleted.', 'success');
          fetchProjects();
        } catch (err) {
          Swal.fire('Error', 'Failed to delete project.', 'error');
        }
      }
    });
  };

  // Handler ใหม่สำหรับเปิด Modal ยืนยันการลงทะเบียน
  const handleOpenRegistrationConfirmationModal = (project) => {
    setSelectedProject(project);
    setIsDetailsModalOpen(false);
    setIsConfirmModalOpen(true);
  };

  const handleConfirmRegistration = async (projectId, allergies, suggestions) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      Swal.fire('Success', 'Registration successful!', 'success');

      const newRegistration = {
        registration_id: mockRegistrations.length + 1,
        project_id: projectId,
        std_id: currentUser.std_id,
        registered_at: new Date().toISOString(),
        firstname: currentUser.firstname,
        lastname: currentUser.lastname,
        allergies: allergies,
        suggestions: suggestions,
      };
      setMockRegistrations(prev => [...prev, newRegistration]);

      setIsConfirmModalOpen(false);
    } catch (err) {
      Swal.fire('Error', 'Failed to register.', 'error');
    }
  };

  const handleUnregister = async (projectId) => {
    Swal.fire({
      title: 'คุณแน่ใจไหม?',
      text: "คุณต้องการยกเลิกการลงทะเบียนในโครงการนี้ใช่หรือไม่?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'ใช่, ยกเลิก!',
      cancelButtonText: 'ไม่'
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          setMockRegistrations(prev => prev.filter(reg => !(reg.project_id === projectId && reg.std_id === currentUser.std_id)));
          Swal.fire('ยกเลิกแล้ว!', 'การลงทะเบียนถูกยกเลิกเรียบร้อยแล้ว', 'success');
          setIsDetailsModalOpen(false);
        } catch (err) {
          Swal.fire('Error', 'Failed to unregister.', 'error');
        }
      }
    });
  };

  const handleViewDetails = (project) => {
    setSelectedProject(project);
    setIsDetailsModalOpen(true);
  };

  const handleViewRegistrations = async (projectId) => {
    try {
      setIsDetailsModalOpen(false);
      await new Promise(resolve => setTimeout(resolve, 500));
      const fetchedParticipants = mockRegistrations.filter(reg => reg.project_id === projectId);
      setParticipants(fetchedParticipants);
      setIsParticipantsModalOpen(true);
    } catch (err) {
      Swal.fire('Error', 'Failed to fetch participants.', 'error');
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800">โปรเจกต์</h1>
          {currentUser && (currentUser.role_id === 2 || currentUser.role_id === 3) && (
            <button onClick={() => setIsAddModalOpen(true)} className="inline-flex items-center px-4 py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg shadow-md">
              <FaRegSquarePlus className="mr-2" />เพิ่มโปรเจกต์
            </button>
          )}
        </header>

        <main className="space-y-6">
          {loading ? (
            <div className="text-center p-10"><p>กำลังโหลด...</p></div>
          ) : error ? (
            <div className="text-center p-10 text-red-500"><FaTriangleExclamation className="mx-auto text-4xl mb-2" /><p>{error}</p></div>
          ) : projects.length === 0 ? (
            <div className="text-center p-10"><FaCircleInfo className="mx-auto text-4xl mb-2" /><p>ไม่พบข้อมูลโปรเจกต์</p></div>
          ) : (
            <div className="space-y-4">
              {projects.map((item) => (
                <ProjectCard
                  key={item.project_id}
                  project={item}
                  currentUser={currentUser}
                  onEdit={(project) => {
                    setSelectedProject(project);
                    setIsEditModalOpen(true);
                  }}
                  onDelete={() => handleDeleteProject(item.project_id)}
                  onViewDetails={handleViewDetails}
                  isRegistered={registeredProjects.has(item.project_id)}
                />
              ))}
            </div>
          )}
        </main>

        <AddProjectModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={handleAddProject}
          currentUser={currentUser}
        />
        <EditProjectModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onSave={handleEditProject}
          projectItem={selectedProject}
        />
        <ProjectDetailsModal
          isOpen={isDetailsModalOpen}
          onClose={() => setIsDetailsModalOpen(false)}
          projectItem={selectedProject}
          onViewRegistrations={handleViewRegistrations}
          onOpenRegisterForm={handleOpenRegistrationConfirmationModal}
          onUnregister={handleUnregister}
          isRegistered={selectedProject ? registeredProjects.has(selectedProject.project_id) : false}
          isStudent={currentUser?.role_id === 1}
        />
        <RegistrationConfirmationModal
          isOpen={isConfirmModalOpen}
          onClose={() => setIsConfirmModalOpen(false)}
          onConfirm={handleConfirmRegistration}
          projectItem={selectedProject}
        />
        <ViewParticipantsModal
          isOpen={isParticipantsModalOpen}
          onClose={() => setIsParticipantsModalOpen(false)}
          participants={participants}
        />
      </div>
    </div>
  );
}