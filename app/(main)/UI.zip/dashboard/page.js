import DashboardClientPage from "./DashboardClientPage";

export default function DashboardPage() {
    return (
        <DashboardClientPage />
    );
}