'use client';

import { useState, useEffect } from 'react';
import { FaFilter, FaCalendarCheck } from 'react-icons/fa6'; // เปลี่ยนไอคอนให้เข้ากับปีงบประมาณ
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

// เพิ่มข้อมูลจำลอง: ปีงบประมาณและแผนงาน
const MOCK_PLANS = [
  { plan_id: 'P01', plan_name: 'พัฒนาบุคลากร' },
  { plan_id: 'P02', plan_name: 'วิจัยและนวัตกรรม' },
  { plan_id: 'P03', plan_name: 'บริการวิชาการ' },
];

const MOCK_FISCAL_YEARS = [
  { year: 2568 },
  { year: 2567 },
  { year: 2566 },
];

// ข้อมูลจำลองที่สร้างขึ้นตามโครงสร้างฐานข้อมูลที่ให้มา
const mockApiData = [
  {
    project_id: 1,
    project_title: 'จัดการโครงการนิสิตพบอาจารย์ที่ปรึกษา',
    associated_budget: 150000,
    fiscal_year: 2568, // เพิ่ม fiscal_year
    plan_id: 'P01',
    project_location: 'ภาคปกติ',
  },
  {
    project_id: 2,
    project_title: 'โครงการ Turn it on',
    associated_budget: 280000,
    fiscal_year: 2568,
    plan_id: 'P01',
    project_location: 'ภาคปกติ',
  },
  {
    project_id: 3,
    project_title: 'พัฒนาซอฟต์แวร์',
    associated_budget: 200000,
    fiscal_year: 2568,
    plan_id: 'P02',
    project_location: 'ภาคพิเศษ',
  },
  {
    project_id: 4,
    project_title: 'สัมมนาวิชาการ',
    associated_budget: 250000,
    fiscal_year: 2567, // เปลี่ยนเป็นปี 2567
    plan_id: 'P03',
    project_location: 'ภาคปกติ',
  },
  {
    project_id: 5,
    project_title: 'โครงการนวัตกรรม',
    associated_budget: 170000,
    fiscal_year: 2567,
    plan_id: 'P02',
    project_location: 'ภาคปกติ',
  },
  {
    project_id: 6,
    project_title: 'วิจัยตลาด',
    associated_budget: 60000,
    fiscal_year: 2567,
    plan_id: 'P02',
    project_location: 'ภาคพิเศษ',
  },
  {
    project_id: 7,
    project_title: 'โครงการวิจัย 7',
    associated_budget: 150000,
    fiscal_year: 2566, // เพิ่มปี 2566
    plan_id: 'P02',
    project_location: 'ภาคปกติ',
  },
];

const DashboardClientPage = () => {
  const [selectedFiscalYear, setSelectedFiscalYear] = useState('');
  const [selectedPlan, setSelectedPlan] = useState('');
  const [location, setLocation] = useState('');
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [totalProjects, setTotalProjects] = useState(0);
  const [totalBudget, setTotalBudget] = useState(0);

  // ตั้งค่าปีเริ่มต้นเป็นปีปัจจุบัน (สมมติว่าเป็นปีงบประมาณที่ 2568)
  useEffect(() => {
    setSelectedFiscalYear(MOCK_FISCAL_YEARS[0].year);
  }, []);

  useEffect(() => {
    handleFilter();
  }, [selectedFiscalYear, selectedPlan, location]);

  const handleFilter = () => {
    const filteredData = mockApiData.filter(project => {
      const matchYear = !selectedFiscalYear || project.fiscal_year === Number(selectedFiscalYear);
      const matchPlan = !selectedPlan || project.plan_id === selectedPlan;
      const matchLocation = !location || project.project_location === location;
      return matchYear && matchPlan && matchLocation;
    });

    setFilteredProjects(filteredData);

    const projectsCount = filteredData.length;
    const budgetSum = filteredData.reduce((sum, item) => sum + item.associated_budget, 0);

    setTotalProjects(projectsCount);
    setTotalBudget(budgetSum);
  };

  const formatCurrency = (value) => {
    if (value === undefined || value === null) return '฿0';
    return new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', minimumFractionDigits: 0 }).format(value);
  };

  // ใช้ filteredProjects โดยตรงเป็นข้อมูลสำหรับกราฟ
  const chartData = filteredProjects.map(project => ({
    ...project,
    'จำนวนโครงการ': 1,
    'งบประมาณ': project.associated_budget,
  }));

  return (
    <div className="min-h-screen p-4 sm:p-8 font-sans bg-gray-100">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">
          โครงการและงบประมาณที่ใช้
        </h1>

        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 sm:p-6 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                ปีงบประมาณ
              </label>
              <select
                value={selectedFiscalYear}
                onChange={(e) => setSelectedFiscalYear(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">ทั้งหมด</option>
                {MOCK_FISCAL_YEARS.map((fy) => (
                  <option key={fy.year} value={fy.year}>{fy.year}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                แผนงาน
              </label>
              <select
                value={selectedPlan}
                onChange={(e) => setSelectedPlan(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">ทั้งหมด</option>
                {MOCK_PLANS.map((plan) => (
                  <option key={plan.plan_id} value={plan.plan_id}>{plan.plan_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                ภาค
              </label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">ทั้งหมด</option>
                <option value="ภาคปกติ">ภาคปกติ</option>
                <option value="ภาคพิเศษ">ภาคพิเศษ</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow p-6 text-center">
            <p className="text-sm font-medium text-gray-500">จำนวนโครงการทั้งหมด</p>
            <p className="text-4xl font-bold text-gray-800 mt-2">{totalProjects}</p>
          </div>
          <div className="bg-white rounded-lg shadow p-6 text-center">
            <p className="text-sm font-medium text-gray-500">งบประมาณที่ใช้ทั้งหมด</p>
            <p className="text-4xl font-bold text-indigo-600 mt-2">{formatCurrency(totalBudget)}</p>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 sm:p-15 h-[600px]">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">
            กราฟงบประมาณและจำนวนโครงการ
          </h2>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 5, right: 30, left: 30, bottom: 5 }}
            >
              <XAxis
                dataKey="project_title"
                textAnchor="end"
                interval={0}
                tickFormatter={(tick) => (tick.length > 20 ? `${tick.substring(0, 20)}...` : tick)}
                tick={{ fontSize: 10 }}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="งบประมาณ" fill="#03A96B" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default DashboardClientPage;