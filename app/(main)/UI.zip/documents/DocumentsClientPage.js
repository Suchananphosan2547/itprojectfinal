'use client';

import { useState, useEffect } from 'react';
import { FaFileAlt, FaDownload, FaTimes, FaEye, FaArrowLeft } from 'react-icons/fa';
import Swal from 'sweetalert2';

// ข้อมูลโครงการที่จบแล้วจำลองจากฐานข้อมูล
const mockFinishedProjects = [
  { id: 1, name: 'โครงการอบรมเชิงปฏิบัติการ Python สำหรับ Data Science' },
  { id: 2, name: 'โครงการสัมมนาวิชาการด้านเทคโนโลยี AI' },
  { id: 3, name: 'โครงการวิจัยและพัฒนาแอปพลิเคชันเพื่อสุขภาพ' },
];

// Modal Component สำหรับสร้างเอกสาร (ปรับปรุงใหม่)
const CreateDocumentModal = ({ isOpen, onClose }) => {
  const [view, setView] = useState('form'); // 'form' หรือ 'preview'
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [budgetUsed, setBudgetUsed] = useState('');
  const [problems, setProblems] = useState('');
  const [solutions, setSolutions] = useState('');

  // ฟังก์ชันรีเซ็ตค่าในฟอร์ม
  const resetForm = () => {
    setSelectedProjectId('');
    setBudgetUsed('');
    setProblems('');
    setSolutions('');
  };

  // ใช้ useEffect เพื่อรีเซ็ตฟอร์มและสถานะ view เมื่อ Modal ถูกปิด
  useEffect(() => {
    if (!isOpen) {
      // ใช้ setTimeout เพื่อให้เวลา animation การปิดทำงานก่อนที่จะรีเซ็ตค่า
      setTimeout(() => {
        resetForm();
        setView('form');
      }, 300);
    }
  }, [isOpen]);

  // ฟังก์ชันจัดการเมื่อกดปุ่ม "ดูตัวอย่าง"
  const handlePreview = () => {
    if (!selectedProjectId || !budgetUsed || !problems || !solutions) {
      Swal.fire('ข้อผิดพลาด', 'กรุณากรอกข้อมูลให้ครบถ้วน', 'error');
      return;
    }
    setView('preview');
  };

  // ฟังก์ชันยืนยันการดาวน์โหลด
  const handleConfirmDownload = () => {
    console.log('Downloading with data:', { selectedProjectId, budgetUsed, problems, solutions });

    Swal.fire({
      title: 'ดาวน์โหลดสำเร็จ!',
      text: 'ไฟล์เอกสารของคุณพร้อมแล้ว',
      icon: 'success',
      confirmButtonText: 'ตกลง'
    });

    onClose(); // ปิด Modal หลังจากดาวน์โหลด
  };

  // จัดการ input งบประมาณให้รับเฉพาะตัวเลข
  const handleBudgetChange = (e) => {
    const numericValue = e.target.value.replace(/[^0-9]/g, '');
    setBudgetUsed(numericValue);
  };

  const selectedProject = mockFinishedProjects.find(p => p.id === parseInt(selectedProjectId));

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center ">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl transform transition-all duration-300 ease-out">
        <div className="p-6">
          <div className="flex justify-between items-center border-b pb-4 mb-4">
            <h3 className="text-xl font-semibold text-gray-800">เอกสารแบบสรุปผลการดำเนินงานโครงการ</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-700 text-2xl">
              <FaTimes />
            </button>
          </div>

          {/* ----- ส่วนแสดงผลตามสถานะ (View) ----- */}
          {view === 'form' ? (
            // ----- VIEW: FORM -----
            <div className="space-y-4">
              <div>
                <label htmlFor="project-name" className="block text-sm font-medium text-gray-700">ชื่อโครงการ</label>
                <select
                  id="project-name"
                  value={selectedProjectId}
                  onChange={(e) => setSelectedProjectId(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="">-- กรุณาเลือกโครงการ --</option>
                  {mockFinishedProjects.map(project => (
                    <option key={project.id} value={project.id}>{project.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="budget-used" className="block text-sm font-medium text-gray-700">งบประมาณที่ใช้จริง (บาท)</label>
                <input
                  type="text"
                  id="budget-used"
                  value={budgetUsed ? parseInt(budgetUsed).toLocaleString() : ''}
                  onChange={handleBudgetChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2"
                  placeholder="กรอกเฉพาะตัวเลข"
                />
              </div>
              <div>
                <label htmlFor="problems" className="block text-sm font-medium text-gray-700">ปัญหาและอุปสรรคที่พบ</label>
                <textarea
                  id="problems"
                  value={problems}
                  onChange={(e) => setProblems(e.target.value)}
                  rows="3"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 focus:ring-indigo-500 focus:border-indigo-500"
                ></textarea>
              </div>
              <div>
                <label htmlFor="solutions" className="block text-sm font-medium text-gray-700">แนวทางการแก้ไขและพัฒนาในอนาคต</label>
                <textarea
                  id="solutions"
                  value={solutions}
                  onChange={(e) => setSolutions(e.target.value)}
                  rows="3"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 focus:ring-indigo-500 focus:border-indigo-500"
                ></textarea>
              </div>
            </div>
          ) : (
            // ----- VIEW: PREVIEW -----
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-700 mb-2">ตัวอย่างเอกสาร</h4>
              <div className="bg-gray-50 p-4 rounded-md border border-gray-200 space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-500">ชื่อโครงการ</p>
                  <p className="font-semibold text-gray-800">{selectedProject?.name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">งบประมาณที่ใช้จริง</p>
                  <p className="font-semibold text-gray-800">{parseInt(budgetUsed).toLocaleString('th-TH', { style: 'currency', currency: 'THB' })}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">ปัญหาและอุปสรรค</p>
                  <p className="text-gray-800 whitespace-pre-wrap">{problems}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">แนวทางการแก้ไข</p>
                  <p className="text-gray-800 whitespace-pre-wrap">{solutions}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ----- ส่วน Footer ของ Modal ----- */}
        <div className="flex justify-end gap-3 mt-6 p-4 border-t bg-gray-50 rounded-b-lg">
          {view === 'form' ? (
            <button
              onClick={handlePreview}
              className="inline-flex items-center px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md shadow-sm hover:bg-indigo-700 transition-colors"
            >
              <FaEye className="mr-2" />
              <span>ดูตัวอย่าง</span>
            </button>
          ) : (
            <>
              <button
                onClick={() => setView('form')}
                className="inline-flex items-center px-6 py-2 bg-gray-200 text-gray-800 font-semibold rounded-md hover:bg-gray-300 transition-colors"
              >
                <FaArrowLeft className="mr-2" />
                <span>ย้อนกลับ</span>
              </button>
              <button
                onClick={handleConfirmDownload}
                className="inline-flex items-center px-6 py-2 bg-teal-600 text-white font-semibold rounded-md shadow-sm hover:bg-teal-700 transition-colors"
              >
                <FaDownload className="mr-2" />
                <span>ยืนยันและดาวน์โหลด</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};


// Component หลักของหน้า (เหมือนเดิม)
export default function DocumentsClientPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="min-h-screen p-4 sm:p-8 font-sans bg-gray-100">
      <div className="max-w-7xl mx-auto">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-gray-800">
            เอกสารทั้งหมด
          </h1>
        </header>

        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 sm:p-6">
          <ul className="divide-y divide-gray-200">
            <li className="py-4">
              <div
                onClick={() => setIsModalOpen(true)}
                className="flex items-center space-x-3 text-lg font-medium text-gray-700 hover:text-indigo-600 cursor-pointer transition-colors"
              >
                <FaFileAlt className="text-xl text-indigo-500" />
                <span>เอกสารแบบสรุปผลการดำเนินงานโครงการ</span>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <CreateDocumentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}