import DocumentsClientPage from "./DocumentsClientPage";

export default function DocumentsPage() {
    return (
        <DocumentsClientPage />
    );
}